{
    "name": "Group Exercise 10",
    
    "summary": "",
    
    "description": """
    """,
    
    "version": "0.1",
    
    "category": "Kauil/registry",
    
    "license": "OPL-1",
    
    "depends": ["motorcycle_registry", "web_map"],
    "data": [
        "views/map_view.xml",
        'views/menu_items.xml'
    ],
    
    "demo": [
       
    ],
    
    "author": "kauil-motors",
    
    "website": "www.odoo.com",
    
    "application": True,
    
}